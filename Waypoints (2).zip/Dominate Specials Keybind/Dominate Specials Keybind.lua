local mod_name = "Dominate Specials Keybind"  
local loaded = rawget(_G, mod_name)
local c = loaded or rawset(_G, mod_name, {lastpress = 0}) and _G[mod_name] 

if not loaded then
    c.orig_unit_leave_group = GroupAIStateBase.unit_leave_group

    -- fixes [string "lib/managers/group_ai_states/groupaistatebase..."]:4720: attempt to index local 'group' (a nil value)
    function GroupAIStateBase:unit_leave_group(unit, ...)
        local brain = alive(unit) and unit:brain()

        if brain and brain._logic_data.group then
            c.orig_unit_leave_group(self, unit, ...)
        end
    end
end

if (Application:time() - c.lastpress) < 0.2 then
    c.toggle = not c.toggle
    managers.mission:_show_debug_subtitle(c.toggle and mod_name .. " - Activated" or mod_name .. " - Deactivated", c.toggle and Color.green:with_alpha(0.9) or Color.red:with_alpha(0.9))

    if c.toggle then
        c.orig_has_room_for_police_hostage = c.orig_has_room_for_police_hostage or GroupAIStateBase.has_room_for_police_hostage
        c.orig_convert_to_criminal = c.orig_convert_to_criminal or CopBrain.convert_to_criminal
        c.orig_CopLogicIdle = c.orig_CopLogicIdle or CopLogicIdle.on_intimidated
        c.orig_on_intimidated = c.orig_on_intimidated or CopBrain.on_intimidated
        c.orig_convert_enemies_max_minions = c.orig_convert_enemies_max_minions or tweak_data.upgrades.values.player.convert_enemies_max_minions

        local sandbox = rawget(_G, "Dominate Specials")

        if not sandbox or not sandbox:is_mod_allowed() then
            return
        end

        --tweak_data.upgrades.values.player.convert_enemies_max_minions = {99, 99} -- max 198 converts when aced
        CopLogicIdle.on_intimidated = CopLogicIdle._surrender -- dom specials

        -- inf hostages
        --function GroupAIStateBase:has_room_for_police_hostage()
        --    return true
        --end

        -- reapply shield to shields
        function CopBrain:convert_to_criminal(...)
            c.orig_convert_to_criminal(self, ...)
            self._unit:movement():add_weapons()

            local base = self._unit:base()

            if base:has_tag("shield") then
                self._unit:inventory():shield_unit():set_enabled(true)

                if base:has_tag("phalanx_vip") then
                    CopLogicPhalanxVip.breakup()
                end
            end
        end

        function CopBrain:on_intimidated(amount, aggressor_unit)
            local interaction_voice = self:interaction_voice()

            if interaction_voice then
                self:set_objective(self._logic_data.objective.followup_objective)

                return interaction_voice
            else
                local inventory, effect = self._unit:inventory()

                if inventory and inventory:shield_unit() then
                    self._logic_variants[self._unit:base()._tweak_table].intimidated = CopLogicIntimidated -- dom shields

                    if self._unit:base():has_any_tag({"phalanx_vip", "phalanx_minion"}) then
                        amount = 8
                    end
                end

                self._current_logic.on_intimidated(self._logic_data, amount, aggressor_unit)
            end
        end
    else
        tweak_data.upgrades.values.player.convert_enemies_max_minions = c.orig_convert_enemies_max_minions
        GroupAIStateBase.has_room_for_police_hostage = c.orig_has_room_for_police_hostage
        CopBrain.convert_to_criminal = c.orig_convert_to_criminal
        CopBrain.on_intimidated = c.orig_on_intimidated
        CopLogicIdle.on_intimidated = c.orig_CopLogicIdle
    end
else
	local from, to = managers.viewport:get_current_camera_position(), managers.viewport:get_current_camera_rotation():y()
	mvector3.multiply(to, 1875)
	mvector3.add(to, from)

	local ray = World:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("enemies"))
	local unit = ray and ray.unit

	if alive(unit) then
		if Network:is_client() then
			local session = managers.network:session()
			
			if session then
				local host = session:server_peer()

				host:send("long_dis_interaction", unit, 1, host:unit(), false)
			end
		else
			unit:brain():on_intimidated(0.1, managers.player:player_unit())
		end
	end
end
c.lastpress = Application:time()