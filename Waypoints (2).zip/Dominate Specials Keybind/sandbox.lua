local class_name = "Dominate Specials"
local loaded = rawget(_G, class_name)
local c = loaded or rawset(_G, class_name, {recived_peers = {}, mod_path = ModPath}) and _G[class_name]

if not loaded then
	-- check players recently played with (if reconnecting after entering menu and such)
	function c:is_recent(user_id)
		for _, user in ipairs(Steam:logged_on() and Steam:friends() or {}) do
			if user:id() == user_id then
				return true
			end
		end
	end

	function c:is_mod_allowed()
		local settings = Global.game_settings

		if settings and (settings.single_player or settings.permission ~= "public") then
			return true
		end

		for _, peer in pairs(managers.network:session():peers()) do
			if c.recived_peers[peer:user_id()] == nil then
				return
			end
		end

		return true
	end
end

local orig_set_outfit_string = NetworkPeer.set_outfit_string
function NetworkPeer:set_outfit_string(...)
	local session = managers.network:session()
	local local_peer = session and session:local_peer()

	if local_peer and self:id() ~= local_peer:id() then
		DelayedCalls:Add(class_name .. self:id(), 3, function()
			LuaNetworking:SendToPeer(self:id(), class_name, tostring(local_peer:id()))

			if not c:is_mod_allowed() and rawget(_G, "Dominate Specials Keybind") and rawget(_G, "Dominate Specials Keybind").toggle then
				dofile(c.mod_path .. "Dominate Specials Keybind.lua")
				dofile(c.mod_path .. "Dominate Specials Keybind.lua")
			end
		end)
	end

	return orig_set_outfit_string(self, ...)
end

--receive as client/host
Hooks:Add("NetworkReceivedData", class_name, function(peer_id, id, data)
	if id == class_name and data and #data == 1 then
		local sender = managers.network:session():peer(tonumber(data))
		local user_id = sender and sender:user_id()

		if user_id and c.recived_peers[user_id] == nil then
			c.recived_peers[user_id] = true

			if not c:is_recent(user_id) then
				managers.chat:_receive_message(1, class_name, string.format("Can be used with %s.", sender:name()), Color.green)
			end
		end
	end
end)