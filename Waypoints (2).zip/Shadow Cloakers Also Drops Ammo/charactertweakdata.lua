Hooks:PostHook(CharacterTweakData, "_init_shadow_spooc", "_set_shadow_spooc", function(self)
    self.shadow_spooc.do_not_drop_ammo = false
end)