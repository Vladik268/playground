function PlayerMovement:on_SPOOCed(enemy_unit)
	return "countered"
end