function PlayerStandard:set_night_vision_state(state)
	local mask_id = managers.blackmarket:equipped_mask().mask_id
	local mask_tweak = tweak_data.blackmarket.masks[mask_id]

	if not mask_tweak.night_vision or self._state_data.night_vision_active == state then
		return
	end

	if state then
		managers.viewport:create_global_environment_modifier(CoreEnvironmentFeeder.PostAmbientColorFeeder.DATA_PATH_KEY, true, function()
			return Vector3(2.5, 5.5, 2.5)
		end)
	else
		managers.viewport:destroy_global_environment_modifier(CoreEnvironmentFeeder.PostAmbientColorFeeder.DATA_PATH_KEY)
	end

	self._unit:sound():play(state and "night_vision_on" or "night_vision_off", nil, false)
	self._state_data.night_vision_active = state
end