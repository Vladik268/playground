if not SimpleMenu then
    SimpleMenu = class()

    function SimpleMenu:init(title, message, options)
        self.dialog_data = { title = title, text = message, button_list = {},
                             id = tostring(math.random(0,0xFFFFFFFF)) }
        self.visible = false
        for _,opt in ipairs(options) do
            local elem = {}
            elem.text = opt.text
            opt.data = opt.data or nil
            opt.callback = opt.callback or nil
            elem.callback_func = callback(self, self, "_do_callback",
                                          { data = opt.data,
                                            callback = opt.callback})
            elem.cancel_button = opt.is_cancel_button or false
            if opt.is_focused_button then
                self.dialog_data.focus_button = #self.dialog_data.button_list+1
            end
            table.insert(self.dialog_data.button_list, elem)
        end
        return self
    end

    function SimpleMenu:_do_callback(info)
        if info.callback then
            if info.data then
                info.callback(info.data)
            else
                info.callback()
            end
        end
        self.visible = false
    end

    function SimpleMenu:show()
        if self.visible then
            return
        end
        self.visible = true
        managers.system_menu:show(self.dialog_data)
    end

    function SimpleMenu:hide()
        if self.visible then
            managers.system_menu:close(self.dialog_data.id)
            self.visible = false
            return
        end
    end
end

patched_update_input = patched_update_input or function (self, t, dt )
    if self._data.no_buttons then
        return
    end
    
    local dir, move_time
    local move = self._controller:get_input_axis( "menu_move" )

    if( self._controller:get_input_bool( "menu_down" )) then
        dir = 1
    elseif( self._controller:get_input_bool( "menu_up" )) then
        dir = -1
    end
    
    if dir == nil then
        if move.y > self.MOVE_AXIS_LIMIT then
            dir = 1
        elseif move.y < -self.MOVE_AXIS_LIMIT then
            dir = -1
        end
    end

    if dir ~= nil then
        if( ( self._move_button_dir == dir ) and self._move_button_time and ( t < self._move_button_time + self.MOVE_AXIS_DELAY ) ) then
            move_time = self._move_button_time or t
        else
            self._panel_script:change_focus_button( dir )
            move_time = t
        end
    end

    self._move_button_dir = dir
    self._move_button_time = move_time
    
    local scroll = self._controller:get_input_axis( "menu_scroll" )
    -- local sdir
    if( scroll.y > self.MOVE_AXIS_LIMIT ) then
        self._panel_script:scroll_up()
        -- sdir = 1
    elseif( scroll.y < -self.MOVE_AXIS_LIMIT ) then
        self._panel_script:scroll_down()
        -- sdir = -1
    end
end
managers.system_menu.DIALOG_CLASS.update_input = patched_update_input
managers.system_menu.GENERIC_DIALOG_CLASS.update_input = patched_update_input

cuffed = cuffed or function()
	function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			for pl_key, pl_record in pairs(managers.groupai:state():all_player_criminals()) do
				if pl_record.status ~= "arrested" then
					local unit = managers.groupai:state():all_player_criminals()[pl_key].unit
					if unit:network():peer():id() == id then
						unit:network():send_to_unit({"sync_player_movement_state", unit, "arrested", 2, unit:id()})
					end 
				end	
			end	
		end
	end
	function Use_Peers(id)
		for pl_key, pl_record in pairs( managers.groupai:state():all_player_criminals() ) do
			if pl_record.status ~= "arrested" then
				local unit = managers.groupai:state():all_player_criminals()[ pl_key ].unit
				unit:network():send_to_unit( { "sync_player_movement_state", unit, "arrested", 0, unit:id() } )
			end
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Cuff all", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Cuffed", "Select who to cuff", menu_options)
		menu:Show()
	end
end

tased = tased or function(info)
	function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			for pl_key, pl_record in pairs(managers.groupai:state():all_player_criminals()) do
				if pl_record.status ~= "tased" then
					local unit = managers.groupai:state():all_player_criminals()[pl_key].unit
					if unit:network():peer():id() == id then
						unit:network():send_to_unit({"sync_player_movement_state", unit, "tased", 2, unit:id()})
					end
				end
			end
		end
	end
	function Use_Peers(id)
		for pl_key, pl_record in pairs( managers.groupai:state():all_player_criminals() ) do
			if pl_record.status ~= "tased" then
				local unit = managers.groupai:state():all_player_criminals()[ pl_key ].unit
				unit:network():send_to_unit( { "sync_player_movement_state", unit, "tased", 0, unit:id() } )
			end
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Taze all", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Tased", "Select who to taze", menu_options)
		menu:Show()
	end
end

downed = downed or function(info)
    function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			for pl_key, pl_record in pairs(managers.groupai:state():all_player_criminals()) do
				if pl_record.status ~= "incapacitated" then
					local unit = managers.groupai:state():all_player_criminals()[pl_key].unit
					if unit:network():peer():id() == id then
						unit:network():send_to_unit({"sync_player_movement_state", unit, "incapacitated", 2, unit:id()})
					end 
				end	
			end	
		end
	end
	function Use_Peers(id)
		for pl_key, pl_record in pairs( managers.groupai:state():all_player_criminals() ) do
			if pl_record.status ~= "incapacitated" then
				local unit = managers.groupai:state():all_player_criminals()[ pl_key ].unit
				unit:network():send_to_unit( { "sync_player_movement_state", unit, "incapacitated", 0, unit:id() } )
			end
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Down all", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Downed", "Select who to down", menu_options)
		menu:Show()
	end
end

bleedout = bleedout or function(info)
    function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			for pl_key, pl_record in pairs(managers.groupai:state():all_player_criminals()) do
				if pl_record.status ~= "bleed_out" then
					local unit = managers.groupai:state():all_player_criminals()[pl_key].unit
					if unit:network():peer():id() == id then
						unit:network():send_to_unit({"sync_player_movement_state", unit, "bleed_out", 2, unit:id()})
					end 
				end	
			end	
		end
	end
	function Use_Peers(id)
		for pl_key, pl_record in pairs( managers.groupai:state():all_player_criminals() ) do
			if pl_record.status ~= "bleed_out" then
				local unit = managers.groupai:state():all_player_criminals()[ pl_key ].unit
				unit:network():send_to_unit( { "sync_player_movement_state", unit, "bleed_out", 0, unit:id() } )
			end
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Bleedout all", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Bleedout", "Select who to bleedout", menu_options)
		menu:Show()
	end
end

reviev = reviev or function(info)
    function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			for pl_key, pl_record in pairs(managers.groupai:state():all_player_criminals()) do
				if pl_record.status ~= "standard" then
					local unit = managers.groupai:state():all_player_criminals()[pl_key].unit
					if unit:network():peer():id() == id then
						unit:network():send_to_unit({"sync_player_movement_state", unit, "standard", 2, unit:id()})
					end 
				end	
			end	
		end
	end
	function Use_Peers(id)
		for pl_key, pl_record in pairs( managers.groupai:state():all_player_criminals() ) do
			if pl_record.status ~= "standard" then
				local unit = managers.groupai:state():all_player_criminals()[ pl_key ].unit
				unit:network():send_to_unit( { "sync_player_movement_state", unit, "standard", 0, unit:id() } )
			end
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Reviev all", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Reviev", "Select who to reviev", menu_options)
		menu:Show()
	end
end

custody = custody or function(info)
	function Use_Peer(id)
		for _, u_data in pairs(managers.groupai:state():all_player_criminals()) do
			local player = u_data.unit
			local player_id = player:network():peer():id()
			if id == player_id or id == -1 then
				player:network():send("sync_player_movement_state", "dead", 1, player:id())
				player:network():send_to_unit({"spawn_dropin_penalty", true, nil, 1, nil, nil})
				managers.groupai:state():on_player_criminal_death(player:network():peer():id())
			end
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Custody", "Select who to custody", menu_options)
		menu:Show()
	end
end

un_custody = un_custody or function(info)
	function Use_Peer(id)
		local peer = managers.network:session():peer(id)
		if peer and peer:id() ~= managers.network:session():local_peer():id() then
			if Network:is_client() then
				managers.network:session():server_peer():send("request_spawn_member")
			else	
				IngameWaitingForRespawnState.request_player_spawn(id)
			end	
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Release from custody", "Select who to release from custody", menu_options)
		menu:Show()
	end
end

custody_me = custody_me or function(info)
	local player = managers.player:local_player()
	managers.player:force_drop_carry()
	managers.statistics:downed( { death = true } )
	IngameFatalState.on_local_player_dead()
	game_state_machine:change_state_by_name( "ingame_waiting_for_respawn" )
	player:character_damage():set_invulnerable( true )
	player:character_damage():set_health( 0 )
	player:base():_unregister()
	player:base():set_slot( player, 0 )
end

un_custody_all = un_custody_all or function(info)
	if BaseNetworkHandler._gamestate_filter.any_ingame_playing[game_state_machine:last_queued_state_name()] then
		for id = 1, 4, 1 do
			if managers.network:session():peer(id) and not alive(managers.network:session():peer(id):unit()) then
				IngameWaitingForRespawnState.request_player_spawn(id)
			end
		end
	end
end

teleporting = teleporting or function(info)
	function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			local pos
			for pl_key, pl_record in pairs( managers.groupai:state():all_player_criminals() ) do
				if pl_record.status ~= "dead" then
					local unit = managers.groupai:state():all_player_criminals()[ pl_key ].unit
					if unit:network():peer():id() == id then
						pos = unit:position()
					end
				end
			end
			if pos then
				managers.player:warp_to(pos, managers.player:player_unit():rotation())
			end
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Teleporting", "Select player to teleport", menu_options)
		menu:Show()
	end
end

stop = stop or function(info)
	function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			peer:send("start_timespeed_effect", "pause", "pausable", "player;game;game_animation", 0, 1, 3600, 1)
		end
	end
	function Use_Peers(id)
		for peer_id, peer in pairs(managers.network._session._peers) do
			peer:send("start_timespeed_effect", "pause", "pausable", "player;game;game_animation", 0, 1, 3600, 1)
		end
	end
	function Use_Peers_2(id)
		for peer_id, peer in pairs(managers.network._session._peers) do
			peer:send("stop_timespeed_effect", "pause", 1)
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Stop all", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Restore all", callback = Use_Peers_2}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Stop", "Select who to stop", menu_options)
		menu:Show()
	end
end

slow_mo = slow_mo or function(info)
	function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			peer:send("start_timespeed_effect", "pause", "pausable", "player;game;game_animation", 0.05, 1, 3600, 1)
		end
	end
	function Use_Peers(id)
		for peer_id, peer in pairs(managers.network._session._peers) do
			peer:send("start_timespeed_effect", "pause", "pausable", "player;game;game_animation", 0.05, 1, 3600, 1)
		end
	end
	function Use_Peers_2(id)
		for peer_id, peer in pairs(managers.network._session._peers) do
			peer:send("stop_timespeed_effect", "pause", 1)
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Slow all", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Restore all", callback = Use_Peers_2}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Slow-mo", "Select who to slow", menu_options)
		menu:Show()
	end
end

speedup = speedup or function(info)
	function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			peer:send("start_timespeed_effect", "pause", "pausable", "player;game;game_animation", 10, 1, 3600, 1)
		end
	end
	function Use_Peers(id)
		for peer_id, peer in pairs(managers.network._session._peers) do
			peer:send("start_timespeed_effect", "pause", "pausable", "player;game;game_animation", 10, 1, 3600, 1)
		end
	end
	function Use_Peers_2(id)
		for peer_id, peer in pairs(managers.network._session._peers) do
			peer:send("stop_timespeed_effect", "pause", 1)
		end
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name(), data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		menu_options[#menu_options+1] = {text = "Speedup all", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Restore all", callback = Use_Peers_2}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("SpeedUp", "Select who to Speedup", menu_options)
		menu:Show()
	end
end

crash = crash or function(info)
	function Use_Peer(id)
		local peer = managers.network._session:peer(id)
		if peer then
			if (LuaNetworking:LocalPeerID() == peer:id()) then
				managers.hint:sync_show_hint("sync_show_hint")
			else
				peer:send("sync_show_hint", id)
			end
		end
	end
	function Use_Peers(id)
		for peer_id, peer in pairs(managers.network._session._peers) do
			peer:send("sync_show_hint", id)
		end
		local playersLen = table.size(managers.network:session():peers())
	end
	if managers.network._session then
		local menu_options = {}
		for _, peer in pairs(managers.network:session():peers()) do
			if peer:rank() and peer:level() then
				menu_options[#menu_options+1] ={text = "(" .. peer:rank() .. "-" .. peer:level() .. ") " .. peer:name() .. " (" .. peer:id() .. ")", data = peer:id(), callback = Use_Peer}
			else
				menu_options[#menu_options+1] ={text = peer:name(), data = peer:id(), callback = Use_Peer}
			end
		end
		
		local peerLocal = managers.network._session:peer(LuaNetworking:LocalPeerID())
		if peerLocal:rank() and peerLocal:level() then
			menu_options[#menu_options+1] ={text = "(" .. peerLocal:rank() .. "-" .. peerLocal:level() .. ") " .. peerLocal:name() .. " (" .. peerLocal:id() .. ")", data = peerLocal:id(), callback = Use_Peer}
		else
			menu_options[#menu_options+1] ={text = peerLocal:name() .. " (" .. peerLocal:id() .. ")", data = peerLocal:id(), callback = Use_Peer}
		end
		
		menu_options[#menu_options+1] = {text = "Crash whole lobby", callback = Use_Peers}
		menu_options[#menu_options+1] = {text = "Cancel", is_cancel_button = true}
		local menu = QuickMenu:new("Crash", "Select a player to crash him game <3", menu_options)
		menu:Show()
	end
end

opts = {
	{ text = "Cuff", callback = cuffed },
	{ text = "Taze", callback = tased },
	{ text = "Downed", callback = downed },
	{ text = "Bleedout", callback = bleedout },
	{ text = "Reviev", callback = reviev },
	{ text = "Custody", callback = custody },
	{ text = "Release", callback = un_custody },
	{ text = "Enter in custody", callback = custody_me },
	{ text = "Release all from custody", callback = un_custody_all },
	{ text = "Teleporting", callback = teleporting },	
	{ text = "Stop", callback = stop },
	{ text = "Slow-mo", callback = slow_mo },
	{ text = "SpeedUp", callback = speedup },
	{ text = "Crash", callback = crash },
	{ text = "Cancel", is_cancel_button = true },
}
mymenu = SimpleMenu:new("Player state", "Choose state and player", opts)
mymenu:show()